"""
ComparadorPrecos — Price Collector API (FastAPI) ready for deployment.

Includes scrapers for Fnac, Worten, PCDIGA and Amazon (.es).
Authentication: JWT (default user from env or .env)
"""
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
import os, requests, re, statistics, json
from bs4 import BeautifulSoup
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./prices.db")
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "change_this_secret_in_prod")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))
APP_DEFAULT_USER = os.getenv("APP_DEFAULT_USER", "admin")
APP_DEFAULT_PASS = os.getenv("APP_DEFAULT_PASS", "1234")

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    sku = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    offers = relationship("Offer", back_populates="product")

class Offer(Base):
    __tablename__ = "offers"
    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"))
    source = Column(String)
    price = Column(Float)
    currency = Column(String(8), default="EUR")
    url = Column(Text)
    phone = Column(String, nullable=True)
    email = Column(String, nullable=True)
    availability = Column(Boolean, default=True)
    scraped_at = Column(DateTime, default=datetime.utcnow)
    product = relationship("Product", back_populates="offers")

Base.metadata.create_all(bind=engine)

class ScrapeRequest(BaseModel):
    url: str
    product_title: Optional[str] = None
    source_name: Optional[str] = None

class Token(BaseModel):
    access_token: str
    token_type: str

class OfferOut(BaseModel):
    id: int; source: Optional[str]; price: float; currency: str; url: str; phone: Optional[str]; email: Optional[str]; availability: bool; scraped_at: datetime
    class Config:
        orm_mode = True

class ProductOut(BaseModel):
    id: int; title: str; sku: Optional[str]; created_at: datetime
    class Config:
        orm_mode = True

# utils
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; PriceBot/1.0)"}
PRICE_RE = re.compile(r"\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})")
PHONE_RE = re.compile(r"\+?\d[\d\-\s()]{6,}\d")
EMAIL_RE = re.compile(r"[\w\.-]+@[\w\.-]+")

def parse_price_text(text: str):
    if not text: return None
    m = PRICE_RE.search(text.replace('\\xa0',' '))
    if not m: return None
    raw = m.group(0).replace('.','').replace(',','.')
    try: return float(raw)
    except: return None

def scrape_fnac(soup):
    price=None
    script = soup.find('script', type='application/ld+json')
    if script:
        try:
            payload = json.loads(script.string)
            if isinstance(payload, dict) and 'offers' in payload and 'price' in payload['offers']: price = float(payload['offers']['price'])
        except: pass
    if price is None:
        for sel in ['.f-price .price', '.product-price', '.fnac-price', '.price-panel .price']:
            el = soup.select_one(sel)
            if el:
                price = parse_price_text(el.get_text()); 
                if price: break
    return price

def generic_scrape(url):
    try:
        r = requests.get(url, headers=HEADERS, timeout=15); r.raise_for_status()
    except Exception as e: return {"error": str(e)}
    soup = BeautifulSoup(r.text, "html.parser")
    if 'fnac.' in url: price = scrape_fnac(soup)
    else:
        # fallback: json-ld or first price-like text
        price=None
        script = soup.find('script', type='application/ld+json')
        if script:
            try:
                payload = json.loads(script.string)
                if isinstance(payload, dict) and 'offers' in payload and 'price' in payload['offers']: price = float(payload['offers']['price'])
            except: pass
        if price is None:
            price = parse_price_text(' '.join(list(soup.stripped_strings)[:400]))
    phone = PHONE_RE.search(r.text); email = EMAIL_RE.search(r.text)
    return {'price': price, 'currency':'EUR', 'phone': phone.group(0) if phone else None, 'email': email.group(0) if email else None, 'error': None}

# auth simple
from passlib.context import CryptContext
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
_default_user = {"username": APP_DEFAULT_USER, "hashed": pwd.hash(APP_DEFAULT_PASS)}
def authenticate(u,p):
    return u==_default_user["username"] and pwd.verify(p, _default_user["hashed"])

def create_token(sub):
    return jwt.encode({"sub": sub, "exp": datetime.utcnow()+timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)}, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)

from fastapi import Request
def require_auth(request: Request):
    auth = request.headers.get("Authorization")
    if not auth or not auth.lower().startswith("bearer "): raise HTTPException(401,"Not authenticated")
    token = auth.split(" ",1)[1]
    try:
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
    except Exception:
        raise HTTPException(401,"Invalid token")
    return payload.get("sub")

app = FastAPI(title="ComparadorPrecos API", version="1.0")

@app.get("/", response_class=HTMLResponse)
def root(): return HTMLResponse("<h1>ComparadorPrecos API — pronto</h1><p>Acede /custom-docs</p>")

@app.get("/custom-docs", include_in_schema=False)
def custom_docs():
    from fastapi.openapi.docs import get_swagger_ui_html
    return get_swagger_ui_html(openapi_url=app.openapi_url, title="ComparadorPrecos Docs")

@app.post("/auth/login", response_model=Token)
def login(body: dict):
    u = body.get("username"); p = body.get("password")
    if not u or not p: raise HTTPException(400,"username/password required")
    if not authenticate(u,p): raise HTTPException(401,"Invalid credentials")
    return {"access_token": create_token(u), "token_type":"bearer"}

@app.post("/scrape", status_code=201)
def scrape(req: ScrapeRequest, user=Depends(require_auth)):
    db = SessionLocal(); prod = Product(title=req.product_title or req.url); db.add(prod); db.commit(); db.refresh(prod)
    res = generic_scrape(req.url)
    if res.get("error"): db.close(); raise HTTPException(400,res["error"])
    offer = Offer(product_id=prod.id, source=req.source_name or req.url, price=res.get("price",0.0), currency=res.get("currency","EUR"), url=req.url, phone=res.get("phone"), email=res.get("email"), availability=res.get("price") is not None, scraped_at=datetime.utcnow())
    db.add(offer); db.commit(); db.refresh(offer); db.close()
    return {"product_id": prod.id, "offer_id": offer.id}

@app.get("/products", response_model=List[ProductOut])
def products(q: Optional[str]=None, user=Depends(require_auth)):
    db = SessionLocal(); query = db.query(Product); 
    if q: query = query.filter(Product.title.ilike(f"%{q}%"))
    items = query.order_by(Product.created_at.desc()).limit(50).all(); db.close(); return items

@app.get("/products/{product_id}/estimate")
def estimate(product_id: int, user=Depends(require_auth)):
    db = SessionLocal(); offers = db.query(Offer).filter(Offer.product_id==product_id, Offer.availability==True).all(); db.close(); prices=[o.price for o in offers if o.price and o.price>0]; 
    if not prices: return {"product_id": product_id, "market_estimate": None, "sample_size":0}
    if len(prices)<3: est = statistics.median(prices)
    else:
        q1,q3 = statistics.quantiles(prices,n=4)[0], statistics.quantiles(prices,n=4)[2]; iqr=q3-q1; filtered=[p for p in prices if q1-1.5*iqr<=p<=q3+1.5*iqr]; est = statistics.median(filtered or prices)
    return {"product_id": product_id, "market_estimate": est, "sample_size": len(prices)}

@app.get("/health")
def health(): return {"status":"ok","timestamp": datetime.utcnow()}
