# ComparadorPrecos — Deploy package (ready for Render)

1. Cria um repositório no GitHub e sobe todo o conteúdo desta pasta.
2. No Render, cria um novo Web Service -> Deploy from GitHub.
3. Seleciona o repositório e usa as configurações (ou usa o `render.yaml` incluído para Deploy automático):
   - Environment: Docker
   - Build: usar Dockerfile (já incluído)
   - Start command: `uvicorn mvp_price_collector_fastapi:app --host 0.0.0.0 --port $PORT`
4. Define as Environment Variables (Settings -> Environment):
JWT_SECRET_KEY=uma_chave_muito_segura_123456789
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60
APP_DEFAULT_USER=admin
APP_DEFAULT_PASS=1234


Après deploy, abre: `https://<your-service>.onrender.com/custom-docs` to see Swagger UI.
